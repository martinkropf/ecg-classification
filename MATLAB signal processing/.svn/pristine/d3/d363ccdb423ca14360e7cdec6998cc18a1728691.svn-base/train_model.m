function train_model()
    disp('------------ feature extraction ---------------- ');
    RE_CALC_ECGS=0;		% set to 1 for final training and 1 for test
    REBUILD_MODEL=1;		% set to 1 for final training and 1 for test
    N_SPLIT =1;		% set to 1 for final training and 1 for test
    PROC_PARALLEL = 0;
    MIN_P_VALUE = 0;
    %MODEL_TYPE='Ensemble'; 
    % MODEL_TYPE='Ensemble';
    MODEL_TYPE='Ensemble';

    PROCESS_ONLY_TYPE=[];

    if PROC_PARALLEL
        try
            delete(gcp('nocreate'));
        end
        parpool(8);
    end
    
    
    data_dir = '/Users/mk/cinc2017/';
    signal_dir = '/Users/mk/training2017/';

    reffile = [signal_dir, 'REFERENCE.csv'];
    fid = fopen(reffile, 'r');
    if(fid ~= -1)
        Ref = textscan(fid,'%s %s','Delimiter',',');
    else
        error(['Could not open ' reffile ' for scoring. Exiting...'])
    end
    fclose(fid);
    % Header entfernen
    RECORDS = Ref{1};
    target  = Ref{2};
    
    
    %Nur bestimmte Klassen ausw�hlen
    if ~isempty(PROCESS_ONLY_TYPE)
        right_inds=strmatch(PROCESS_ONLY_TYPE,Ref{2});
        RECORDS = RECORDS(right_inds);
        target=target(right_inds);
        N=length(right_inds);
    end

    
    varNames=getVarNames;
    ds={};
    for i=1:length(varNames)
        ds{i}=0;
    end
    res_dataset=cell2dataset(ds,'VarNames',varNames);
    
    
    

    
    
    
    
    
    if RE_CALC_ECGS       
        pars=get_pars(300); % fs = 300 Hz
        tic;
        if PROC_PARALLEL
            parfor i = 1:length(RECORDS)
                fname = RECORDS{i};
                res_dataset(i,:)=ait_challenge([training_data_dir,fname],pars);
            end
        else
            for i = 1:length(RECORDS)
                if mod(i,100)==0
                    disp(['processing record ',int2str(i),'/',int2str(length(RECORDS))]);
                end
                fname = RECORDS{i};
                res_dataset(i,:)=ait_challenge([signal_dir,fname],pars);
            end
        end
        total_time=toc-tic;
        averageTime = total_time/length(RECORDS);
        disp(['Generation of validation set completed.\n  Total time = ' ...
            num2str(total_time) '\n  Average time = ' num2str(averageTime) '\n']);
        save(fullfile(data_dir,'ait_result_dataset.mat'),'res_dataset');
    else
        % load previously calculated results
        load(fullfile(data_dir,'ait_result_dataset.mat'));
    end

    
        
    %schlechte Records filtern
    fileID = fopen('blacklist.csv');
    M=textscan(fileID,'%s');
    blacklist=M{1,1};
    not_blacklisted=ismember(RECORDS,blacklist);
    not_blacklisted_idx = find(not_blacklisted==0);
    if ~isempty(blacklist)
        RECORDS=RECORDS(not_blacklisted_idx);
        target=target(not_blacklisted_idx);
        N=length(not_blacklisted_idx);
        res_dataset=res_dataset(not_blacklisted_idx,:);
    end
    
      
    
    

    %save avbeat
%     for i = 1:length(RECORDS)
%         if mod(i,100)==0
%             disp(['processing record ',int2str(i),'/',int2str(length(RECORDS))]);
%         end
%         fname = RECORDS{i};
%         fname = strrep(fname,'A0000','');
%         fname = strrep(fname,'A000','');
%         fname = strrep(fname,'A00','');
%         fname = strrep(fname,'A0','');
%         fname=['/Users/mk/training2017/avbeats/avbeat_',fname,'.mat'];
%         disp(fname);
%         load(fname);
%         
%     end
            
    

    disp('------------ starting modelling ---------------- ');
    %% Select features
    % At least 2 different values
    % Splits at least one class from any other
    % --- Bringt nichts....
    disp('selecting features with high p-values');
    vars=res_dataset.Properties.VarNames;
    classes=unique(target);
    vars2use=zeros(length(vars),1);

    for i=2:length(vars) % start with 2 to leave out rec-nr 
    %Works also with parfor, but code must be copied in order to support both
    %options - since MIN_P_VALUE == 0 leads to better results, parfor is not
    %necessary
    % parfor i=2:length(vars) 
        j=1;
        if length(unique(res_dataset.(vars{i})))>1 && ~isempty(find(isfinite(res_dataset.(vars{i}))))
        %if ~isempty(find(isfinite(res_dataset.(vars{i}))))
            if MIN_P_VALUE==0
                vars2use(i)=1;
            else
                while j<=length(classes)-1 && vars2use(i)==0
                    % 1) Separate this class from all the rest
                    groups=ones(size(target));
                    groups(strmatch(classes{j},target))=2;
                    p_val=statplot(res_dataset.(vars{i}),groups,'all');
                    if p_val<MIN_P_VALUE && p_val>0
                        disp([vars{i},' - ',num2str(p_val)]);
                        vars2use(i)=1;
                    end
                    % 2) Separate this class form any other
                    k=j+1;
                    while k<=length(classes) && vars2use(i)==0
                        groups=zeros(size(target));
                        groups(strmatch(classes{j},target))=1;
                        groups(strmatch(classes{k},target))=2;
                        p_val=statplot(res_dataset.(vars{i})(find(groups)),groups(find(groups)),'all');
                        if p_val<MIN_P_VALUE && p_val>0
                            disp([vars{i},' - ',num2str(p_val)]);
                            vars2use(i)=1;
                        end                        
                        k=k+1;
                    end
                    j=j+1;
                end
            end
        end
        if vars2use(i)==0
            disp(['variable removed: ', vars{i}]);
        end
        
    end

    %vars2use(43:end)=0;
    save(fullfile(data_dir,'vars2use.mat'),'vars2use');

    
    %% Do Modelling
    if REBUILD_MODEL
        disp('------------ starting modelling ---------------- ');
        % in Ref seltene Klassen (Noise) staerker gewichten

        % Weitere Idee: 
        %   In erstem Random Forest nur nach Noise suchen, dann nur auf
        %   Nicht-Noise-Signale erneut Random Forest anwenden

        weights=ones(length(res_dataset),1);
        for class=['N','A','O','~']
            weights(strmatch(class,target))=1/length(find(strmatch(class,target)));
        end

        res_dataset=res_dataset(:,find(vars2use));

        [nrecords,nfeatures]=size(res_dataset);
        Y_predicted=cell(nrecords,1);
        for i=1:N_SPLIT %
            inds4learning=floor((i-1)*nrecords/N_SPLIT)+1:floor(i*nrecords/N_SPLIT);
            if N_SPLIT==1
                inds4prediction=inds4learning;
            else                
                inds4prediction=setdiff(1:nrecords,inds4learning);
            end

            if strcmp(MODEL_TYPE,'Ensemble')
                res_model = fitensemble(res_dataset(inds4learning,:),[target{inds4learning}]',...
                    'Bag',100,'tree',...
                    'Type','Classification',...
                    'Weights',weights(inds4learning),...
                    'nprint',1);
			Y_predicted(inds4prediction)=cellstr(predict(res_model,double(res_dataset(inds4prediction,:))));
            elseif strcmp(MODEL_TYPE,'TreeBagger')
                if PROC_PARALLEL>0
                    paroptions = statset('UseParallel',true);
                else
                    paroptions = statset('UseParallel',false);
                end
                res_model=TreeBagger(100,res_dataset(inds4learning,:),[target{inds4learning}]',...
                    'OOBPred','on',...
                    'NPrint',1,...
                    'MinLeaf',3,...
                    'Prune','off',...
                    'Method','Classification',...
                    'Weights',weights(inds4learning),...
                    'Surrogate','on',...
                    'PredictorSelection','interaction-curvature',... DHa 2017-01-09, was set to 'allsplits' (default) before. Could also be 'curvature'. see https://de.mathworks.com/help/stats/classification-trees-and-regression-trees.html#bvgp2zo-1
                    'OOBVarImp','on',...
                    'Options',paroptions);
			Y_predicted(inds4prediction)=predict(res_model,double(res_dataset(inds4prediction,:)));
            elseif strcmp(MODEL_TYPE,'interactive')
                tmp=res_dataset(inds4learning,:);
                tmp.target=[target{inds4learning}]';
                 FT=dataset2table(tmp);
                assignin('base', 'FT',FT);
                classificationLearner;

            end
        end
        save(fullfile(data_dir,'last_model.mat'),'res_model');
    else
        % Load last model generated
        load(fullfile(data_dir,'last_model.mat'));
        load('vars2use.mat')
        res_dataset=res_dataset(:,find(vars2use));
        Y_predicted=predict(res_model,double(res_dataset));
    end
    

    %% Write results to answers.txt file
    fid = fopen('answers.txt','w');
    for i=1:length(RECORDS)
        fprintf(fid,'%s,%s\r\n',RECORDS{i},Y_predicted{i});
    end
    fclose(fid);

    %% Scoring
    score2017Challenge

end




