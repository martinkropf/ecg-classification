function [types,rhythmres]=rhythmclass(seq,QRS,classes,amps,widths,fs,pars)

premrel=pars.rhythmclass.premrel;
premabs=pars.rhythmclass.premabs;
nnorm=pars.rhythmclass.nnorm;
maxRationToMedianAmp=pars.rhythmclass.maxRationToMedianAmp;
relBCIdiffCouplet=pars.rhythmclass.relBCIdiffCouplet;

rhythmres=struct(...
        'types',[],...
		'hrtrt',[],...														mittlere heart rate
        'Nscs',[],...														# SCs mit dieser MC
        'majorel',[],...													Prozentsatz an Events mit SC==1 innerhalb der majorclass
        'n_premajure',[],...														# "premature atrial complex" of supraventricular origin
        'NPa',[],...														# "premature atrial complex" of sinus node origin (ohne kompensatorische Pause)
        'NPv',[],...														# "premature ventricular complex" of ventricular origin
        'NPc',[],...														# Couplets
        'NPz',[],...														# Interpolated beats
        'NPp',[],...														# polymorphisms
        'rcopa',[],...														Vektor der relativen kompensatorischen Pausen nach A
        'tRtX50',[],...														# evozierter events mit tRtX>50
        'tRtXmean',[],...													mittlere tRtX von evozierten events
        'tRtXstd',[]...														std(tRtX) von evozierten events
);
nevents=length(QRS);
bci=diff(QRS)/fs;

hrs=60./bci;
hrs_hist=hist(hrs,mean(hrs)*[0.5:0.1:1.5])/length(hrs);
rhythmres.n_hist=length(find(hrs_hist>max(hrs_hist)*0.2));
rhythmres.hist_gap=~isempty(find(diff(hrs_hist(6:end)>0)>0));

hrs_hist2=hist(hrs,mean(hrs)*[0.5:0.05:1.5])/length(hrs);
rhythmres.n_hist2=length(find(hrs_hist2>max(hrs_hist2)*0.2));

amps_hist=hist(amps,mean(amps)*[0.5:0.1:1.5])/length(amps);
rhythmres.n_amps=length(find(amps_hist>max(amps_hist)*0.2));

widths_hist=hist(widths,mean(widths)*[0.5:0.1:1.5])/length(widths);
rhythmres.n_widths=length(find(widths_hist>max(widths_hist)*0.2));


% fh=figure;
% hist(hrs,mean(hrs)*[0.5:0.1:1.5]);
% text(mean(hrs)*0.5,1,['n hist: ',int2str(rhythmres.n_hist)]);
% text(mean(hrs)*0.5,2,['has gap: ',int2str(rhythmres.hist_gap)]);
% keyboard;
% hist(hrs,mean(hrs)*[0.5:0.05:1.5]);
% keyboard;
% hist(amps,mean(amps)*[0.5:0.05:1.5]);
% keyboard;
% hist(widths,mean(widths)*[0.5:0.05:1.5]);
% keyboard;
% delete(fh);



mean_BCI=mean(bci);
rhythmres.hrtrt=60/mean_BCI;
% Anzahl der Subklassen 
rhythmres.Nscs=length(unique(classes));
inds_main_sc=find(classes==1);
rhythmres.majorel=round(length(inds_main_sc)/nevents*100);   

PVCa=0; PVCs=0; PVCv=0; PVCc=0; PVCz=0; PVCp=0; 						% Initialisierung der # gefundener premature beats
rcopa=[];                                       						% Vektor der relativen kompensatorischen Pausen nach A

% Premajure beats detection
% a) relativ zum aktuellen BCI und zum vorigen BCI
dBCI_rel=diff(bci)./bci(1:end-1);
dBCI_rel(end+1)=0;
premajure_inds=find(dBCI_rel<-premrel/100);       					% alle Events mit relativer Vorzeitigkeit
% b) relativ zum Medianen BCI
% dBCI_rel=(bci-median(bci))/median(bci);
% premajure_inds=find(dBCI_rel<-premrel/100);       					% alle Events mit relativer Vorzeitigkeit

premajure_inds=premajure_inds(bci(premajure_inds)<premabs);				% auch abs. muss kleiner schwelle sein
n_premajure=length(premajure_inds);

stable_bci_inds=find(abs(dBCI_rel)<premrel/100)+1;   					% auf diese beats folgt ein relativ gleichbleibendes Intervall

% DHa 2015-10-20 max. rel. Amp. fuer atr. premat beats eingefuehrt
median_amp=median(amps(inds_main_sc));
max_amp=median_amp*maxRationToMedianAmp;

types='N'*ones(size(QRS));

for i=1:n_premajure
	i_event=premajure_inds(i);

	previousInds2use=max(1,i_event-nnorm);							
	cur_nbci=median(bci(previousInds2use));									% ueber nnorm beats gemitteltes Normalintervall

	if dBCI_rel(i_event)<-premrel/100							% Vorzeitig auch im Vergleich zum mittleren Erwartungsintervall - echter PB
		% vorangegangener beat nicht �berm��ig l�nger
		if i_event>1 && types(i_event-1)==types(i_event) && types(i_event)~='V'
			% gl type und noch undifferenziert bzw. nicht nach einem interponierten Schlag
			
			if classes(i_event)==1 && amps(i_event) <= max_amp							% GS 2001-04-24 - Subklasse 1 statt nur gleiche Subklassen 
				PVCa=PVCa+1;											% gleiche Morphologie - Annahme PVCa
				types(i_event)='A';
			else														% verschieden Morphologie - Annahme PVCv
				PVCv=PVCv+1;
				types(i_event)='V';
			end
			if i_event<nevents 
				% wenn vorhanden, gleich noch den n�chsten anschauen, 
				% da der bei interponierten PCs unter Umst�nden gegen-
				% �ber dem aktuellen nicht verk�rzt ist
				if types(i_event+1)==types(i_event)							% gleiche Hauptklasse 
					if dBCI_rel(i_event+1) < -premrel/100		% wieder verk�rzt
						if classes(i_event+1)==classes(i_event-1) &&...
								(bci(i_event+1)+bci(i_event)-cur_nbci)/cur_nbci < relBCIdiffCouplet
							PVCz=PVCz+1;								% zwischen zwei gleichen beats und nicht wesentlich l�nger 
							types(i_event)='Z';								% als der Normalabstand oder k�rzer -> interpoliert
						elseif classes(i_event+1)==classes(i_event)
							PVCc=PVCc+1;								% gleiche (deviante) Morphologie -> couplet
							types(i_event+1)='C';
						else											% drei verschiedene Morphologien -> polymorphism
							PVCp=PVCp+1;
							types(i_event+1)='P';
						end
					else   
						if classes(i_event+1)==classes(i_event) && types(i_event)=='A'				% PAC, gleiche Morphologie -> kompensatorische Pause?
							rcopa(length(rcopa)+1)=dBCI_rel(i_event+1);
						end
					end    % if next_bci_rel < - pp.rhythmclass.premrel/100
				else  % if next_mc==cur_mc  
				   % andere Hauptklasse - nicht vergleichbar
				end   % if next_mc==cur_mc  
			else     % if i_event<length(sig.raw.dlist(:,1))
				% letzter verf�gbarer beat
			end  % if i_event<length(sig.raw.dlist(:,1))
		else % if prev_mc==cur_mc &....
			% nicht wirklich vergleichbar, da andere Hauptklasse oder bereits vorher differenziert
		end % if prev_mc==cur_mc &....
	else  % if cur_bci_rel<-pp.rhythmclass.premrel/100 
		% m�glicherweise ein Normalschlag, der auf eine kompensatorische Pause folgt
	end    % if cur_bci_rel<-pp.rhythmclass.premrel/100 
end   

rhythmres.n_premajure=n_premajure;
rhythmres.perc_premajure=n_premajure/nevents*100;
rhythmres.perc_regular=length(stable_bci_inds)/nevents*100;
rhythmres.NPa=PVCa;
rhythmres.NPv=PVCv;
rhythmres.NPc=PVCc;
rhythmres.NPz=PVCz;
rhythmres.NPp=PVCp;
rhythmres.NPs=PVCs;
if ~isempty(rcopa)
	rhythmres.rcopa=mean(rcopa);
else
	rhythmres.rcopa=NaN;
end
