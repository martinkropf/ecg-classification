function y = arcs_range(x)
% y = arcs_range(x)
%
% DH 2004
%
% calculate min - max of vector x

y=max(x)-min(x);
