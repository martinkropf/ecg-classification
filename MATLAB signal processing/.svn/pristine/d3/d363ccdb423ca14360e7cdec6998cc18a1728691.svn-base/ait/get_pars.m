function pars=get_pars(fs)

pars.removeaverage.dist=0.055;
pars.removeaverage.lmovav=[-0.3,0.6]*fs;
pars.removeaverage.filtfreq=25;
pars.removeaverage.lmovav=[-0.3,0.6]*fs;[pars.removeaverage.b,pars.removeaverage.a]=butter(2,pars.removeaverage.filtfreq*2/fs);		% Filter fuer Blanking

%% detectaf
pars.detectaf.spec_order=12;
[pars.detectaf.b,pars.detectaf.a]=butter(1,[1,30]*2/fs); % filter fuer spec berechnung
pars.detectaf.winfunc='hamming';
pars.detectaf.winpar=0;
pars.detectaf.spec_methode='music';
pars.detectaf.av_pwave_window=[-0.3,-0.07];
pars.detectaf.fr=[0.001,0.5,1,2,5,10,20];
fr=pars.detectaf.fr;
pars.detectaf.bf={};
pars.detectaf.af={};
for i=1:length(fr)-1
	[pars.detectaf.bf{i},pars.detectaf.af{i}]=butter(2,[fr(i),fr(i+1)]*2/fs,'bandpass');
end


%% avbeat
pars.avbeat.avwindow=[-0.3,0.6];
pars.avbeat.npointsmin=0.3;
pars.avbeat.rp=0.2;

%% corrclass
pars.corrclass.scw1=[-0.075,0.075]; 
pars.corrclass.ccmin1=0.95;
pars.corrclass.scw2=[-0.075,0.075]; 
pars.corrclass.ccmin2=0.98;

%% rhythmclass
pars.rhythmclass.premrel=20; 
pars.rhythmclass.premabs=1; 
pars.rhythmclass.nnorm=5; 
pars.rhythmclass.maxRationToMedianAmp=1.5; 
pars.rhythmclass.relBCIdiffCouplet=0.1; 

%% detectevents
pars.detectevents.dmin=1/3000; 
pars.detectevents.nmin=50; 
pars.detectevents.nmax=150; 
[pars.detectevents.b,pars.detectevents.a]=butter(2,[11,20]/fs*2,'bandpass');

arp=0.15*fs;
rrp=0.225*fs;
pars.detectevents.blank_func=[1:-1/rrp:0,zeros(1,2*arp-1),0:1/rrp:1];

pars.detectevents.fpw=[-0.05,0.05];
pars.detectevents.distBorderMin=0.05;

%% isnoise
pars.isnoise.max_sig_amp=2;
pars.isnoise.max_sig_diff=0.5*128/fs;
pars.isnoise.qrs_amp_range=[0.2,2];
pars.isnoise.qrs_width_range=[0.025,0.12];
[pars.isnoise.b_spikes1,pars.isnoise.a_spikes1]=butter(2, [30,70]*2/fs,'stop');
[pars.isnoise.b_spikes2,pars.isnoise.a_spikes2]=butter(2, 10*2/fs, 'low');
pars.isnoise.fr=[0.001,0.5,1,10,20,50,100];
fr=pars.isnoise.fr;
pars.isnoise.b={};
pars.isnoise.a={};
for i=1:length(fr)-1
	[pars.isnoise.b{i},pars.isnoise.a{i}]=butter(2,[fr(i),fr(i+1)]*2/fs,'bandpass');
end
