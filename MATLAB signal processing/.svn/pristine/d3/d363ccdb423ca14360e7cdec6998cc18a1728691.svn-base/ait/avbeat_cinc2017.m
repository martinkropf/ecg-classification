function avbeat=avbeat_cinc2017(ecg,QRS,classes,fs,pars)

avwindow=pars.avbeat.avwindow;
rp=pars.avbeat.rp;
npointsmin=pars.avbeat.npointsmin;

classes_unique=unique(classes);
nevs=length(QRS);
nbeats=0;
avwindow=round(avwindow*fs);
nsamps=max(avwindow)-min(avwindow);
rp=rp*fs;
for j=1:length(classes_unique)	
	SC=classes_unique(j);        
	nbeats=nbeats+1;
	
	average=zeros(nsamps,1);
	beats_per_point=zeros(nsamps,1);
	for i=1:length(QRS)             % Schleife ueber alle Events
		FP=QRS(i);
		% Beginn des aktuellen Beats bestimmen
		from_wanted=(FP+avwindow(1));
		if i>1
			from=max([QRS(i-1)+rp,0,from_wanted]);
		else
			from=max(1,from_wanted);
		end
		% Ende des aktuellen Beats bestimmen
		to_wanted=FP+avwindow(end);
		if i<length(QRS)
			to=min([QRS(i+1)-rp,length(ecg),to_wanted]);
		else
			to=min(to_wanted,length(ecg));
		end
		% aktuellen Beat laden und gemittelten Beat aktualisieren
		if to>from
			this_beat=ecg(from:to);
			this_beat=this_beat-mean(this_beat);
			
			to=from+length(this_beat);
			from_diff=from_wanted-from;
			av_length=min([to_wanted,to])-max([from_wanted,from]);
			from_av=1;
			from_loaded=1;
			if from_diff>0                              % Es wurden auch Samples vor dem gewuenschten Pkt from geladen -> wieder wegschneiden
				from_loaded=from_diff+1;
			elseif from_diff<0                          % nicht alle gewuenschten Samples konnten geladen werden (wahrscheinlich Sig-Anfang) 
				from_av=-from_diff+1;                   % -> nur im tatsaechlich geladenen Bereich mitteln (Problem: immer am Anfang -> wird mit 0 aufgefuellt -> falsch
			end
			to_av=from_av+av_length-1;
			to_loaded=from_loaded+av_length-1;
			weights=beats_per_point(from_av:to_av);
			average(from_av:to_av)=(average(from_av:to_av).*weights+this_beat(from_loaded:to_loaded))./(weights+1);
			beats_per_point(from_av:to_av)=beats_per_point(from_av:to_av)+1;
		end
	end
	nmin=max(beats_per_point)*npointsmin;
	first_found=find(beats_per_point>nmin,1,'first');							% ab diesem Zt-Punkt vor dem FP wurden genug beats dieser klasse gefunden
	last_found=find(beats_per_point>nmin,1,'last');								% bis zu ------- II ---------
	average=average(first_found:last_found);
	found_window=avwindow(1)+[first_found,last_found];

	avbeat.seq{nbeats}	=average;
	avbeat.window{nbeats}=found_window;
	avbeat.SC(nbeats)	=SC;
end


