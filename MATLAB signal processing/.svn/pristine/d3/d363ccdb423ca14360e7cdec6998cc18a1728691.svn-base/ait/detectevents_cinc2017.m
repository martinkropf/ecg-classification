function [QRS2,amps,qrs_widths,qrs_res]=detectevents_cinc2017(ecg,fs,pars)

dmin=pars.detectevents.dmin; 
nmin=pars.detectevents.nmin/60*length(ecg)/fs;
nmax=pars.detectevents.nmax/60*length(ecg)/fs;
b=pars.detectevents.b;
a=pars.detectevents.a;
blank_func=pars.detectevents.blank_func;

bandpass_seq = filtfilt(b,a, ecg);
aseqd=abs(diff(bandpass_seq));  

[QRS2,dd, qrs_range, n_not_sel,iqr_qrs]=arcs_detpick_cinc2017(aseqd,blank_func,dmin,nmin,nmax);
QRS2(QRS2<fs*pars.detectevents.distBorderMin)=[];
QRS2(QRS2>length(ecg)-pars.detectevents.distBorderMin*fs)=[];
qrs_res.dd=dd;
qrs_res.n_not_sel=n_not_sel;
qrs_res.iqr_qrs=iqr_qrs;
qrs_res.qrs_range=qrs_range;

%% Set QRS to fiductial point FP and calc amps
fpw=pars.detectevents.fpw;
amps=zeros(length(QRS2),1);
qrs_widths=zeros(length(QRS2),1);
for i=1:length(QRS2)
	from=max(1,QRS2(i)+fpw(1)*fs);
	to=min(length(ecg),QRS2(i)+fpw(2)*fs);
	cur_seq=ecg(from:to);
	amps(i)=max(cur_seq)-min(cur_seq);
	[~,FP]=max(abs(cur_seq-mean(cur_seq))); % mit Offsetkorrektur
	if FP==length(cur_seq) || FP==1				% kein echtes max
		[~,FP]=max(cur_seq);				% Versuch, einfach das max zu berechnen
		if FP==length(cur_seq) || FP==1				% wieder nichts
			[~,FP]=min(cur_seq);				% Versuch, einfach das min zu berechnen
		end
	end
	cur_seq=cur_seq-mean(cur_seq);
	last_zeroCross_prior_FP=find(diff(cur_seq(1:FP)>0)~=0,1,'last');
	first_zeroCross_post_FP=FP+find(diff(cur_seq(FP:end)>0)~=0,1,'first');
	if isempty(last_zeroCross_prior_FP), last_zeroCross_prior_FP=1; end
	if isempty(first_zeroCross_post_FP), first_zeroCross_post_FP=length(cur_seq); end
	qrs_widths(i)=(first_zeroCross_post_FP-last_zeroCross_prior_FP)/fs;
	QRS2(i)=FP+from-1;
end
