function af_res=detectaf_cinc2017(ecg,QRS,classes,types,atrial_ecg,avbeats,fs,pars)
nevs=length(QRS);

spec_order=pars.detectaf.spec_order;
b=pars.detectaf.b;
a=pars.detectaf.a;
winfunc=pars.detectaf.winfunc;
winpar=pars.detectaf.winpar;
spec_methode=pars.detectaf.spec_methode;
av_pwave_window=pars.detectaf.av_pwave_window;

% ---- Feature 1 - Unregelmaessigkeit der RR-Intervalle
bcis=diff(QRS)/fs;
rrs=60./bcis;
median_rr=median(rrs);
af_res.rr_irregularity=iqr(rrs)/median_rr;
af_res.rr_irregularity2=length(find(abs(rrs-median_rr)>10))/length(rrs)*100;

% --- Feature 2 - Frequenzbereich: Energie im Band zw. 5 u 10 Hz

atrial_ecg(abs(atrial_ecg)>iqr(atrial_ecg)*20)=0; % remove spikes / high amplitude regions
atrial_ecg=filtfilt(b,a,atrial_ecg);
N=length(atrial_ecg);
win_func=get_win_func(length(atrial_ecg),winfunc,winpar);
[Pxx,f]=calc_spec(ecg,spec_methode,win_func,spec_order,N,fs);
stft(1:length(Pxx))=zeros(length(Pxx),1);
stft(1:length(Pxx))=Pxx;
[spec_max,f_max_ind]=max(stft);
af_res.atrial_frequency=f(f_max_ind);

% alternative Methode: Sig-Amp in unterschiedlichen Fr-Baendern
fr=pars.detectaf.fr;
af_res.p_freq=zeros(length(fr)-1,1);
for i=1:length(fr)-1
	fseq=filtfilt(pars.detectaf.bf{i},pars.detectaf.af{i},atrial_ecg);
	af_res.p_freq(i)=std(fseq);
	af_res.p_freq_rel(i)=af_res.p_freq(i)/af_res.p_freq(1);
end

	
% 3) Hoehe der P-Welle im AV-Beat der Main Class bestimmen
% Wird vorerst nur 1 x / Signal verwendet, funktioniert also nicht fuer
% die Bestimmung von Anfang / Ende von AF
P_window=av_pwave_window;
right_av_ind=avbeats.SC==1;
av_window=avbeats.window{right_av_ind};
av_seq=avbeats.seq{right_av_ind};

% Methode 1
pseq_avbeat=av_seq(max(1,-av_window(1)+round(P_window(1)*fs)):...
	min(-av_window(1)+round(P_window(2)*fs)));
%offset=mean(av_seq([1:10,end-9:end]));
offset=mean(av_seq([1:10]));
af_res.P_amplitude=mean(pseq_avbeat-offset);

% Methode 2
seq_before_FP=av_seq(1:-av_window(1));
% letzter Schnittpunkt mit 0-Linie (durch 1. Sample) vor R
if av_seq(-av_window(1))<av_seq(1)
	% S gefunden statt R => versuchen, ein R zu finden
	[Ramp,R] = max(seq_before_FP);
	if Ramp>av_seq(1)+range(seq_before_FP)*0.2 && R > length(seq_before_FP)-0.07*fs
		seq_before_FP=seq_before_FP(1:R);
	else
		seq_before_FP=-seq_before_FP;
	end
end
% Punkt, der am weitesten von der Geraden durch 1. Sample und FP
% liegt
seq_before_FP2=seq_before_FP-seq_before_FP(1);
y=seq_before_FP2/seq_before_FP2(end);
x=(1:length(seq_before_FP2))'/length(seq_before_FP2);
ref_dists=sqrt((2*(x/2-y/2).^2)');
[dist_max,last_point_before_R]=max(ref_dists);
ref_line2=(av_seq(1):(av_seq(last_point_before_R)-av_seq(1))/...
	(last_point_before_R-1):av_seq(last_point_before_R))';
to=min(length(ref_line2),last_point_before_R);
af_res.P_amplitude2=abs(mean(av_seq(1:to)-ref_line2(1:to)));
if af_res.P_amplitude2>range(av_seq)*0.3
	af_res.P_amplitude2=0;
end
% 	fh=figure; plot(av_seq); line(1:to,av_seq(1:to),'Color','r'); line(1:to,ref_line2(1:to));
% 	text(0,0,num2str(af_res.P_amplitude2));
% 	keyboard;
% 	delete(fh);
