function result = ait_challenge(recordName,pars,model)
%
% Sample entry for the 2017 PhysioNet/CinC Challenge.
%
% INPUTS:
% recordName: string specifying the record name to process
%
% OUTPUTS:
% classifyResult: integer value where
%                     N = normal rhythm
%                     A = AF
%                     O = other rhythm
%                     ~ = noisy recording (poor signal quality)
%
% To run your entry on the entire training set in a format that is
% compatible with PhysioNet's scoring enviroment, run the script
% generateValidationSet.m
%
% The challenge function requires that you have downloaded the challenge
% data 'training_set' in a subdirectory of the current directory.
%    http://physionet.org/physiobank/database/challenge/2017/
%
% This dataset is used by the generateValidationSet.m script to create
% the annotations on your training set that will be used to verify that
% your entry works properly in the PhysioNet testing environment.
%
%
% Version 1.0
%
%
% Written by: Chengyu Liu and Qiao Li January 20 2017
%             chengyu.liu@emory.edu  qiao.li@emory.edu
%
% Last modified by:
%
%


if nargin<2
	pars=get_pars(300);
end

if nargin<1
% 	recordName='C:\temp\cinc2017\A00001';% N
 	recordName='C:\temp\cinc2017\A00004';% AF
% 	recordName='C:\temp\cinc2017\A00005';% O
% 	recordName='C:\temp\cinc2017\A00205';% ~
end

classifyResult = 'N'; % default output normal rhythm

recNr=eval(recordName(end-4:end));

%% Load Signals
[tm,ecg,fs,siginfo]=rdmat(recordName);

%% QRS Detection default
[QRS,sign,en_thres] = qrs_detect2(ecg',0.25,0.6,fs);

%% QRS Detection AIT
[QRS2,amps,qrs_widths,qrs_res]=detectevents_cinc2017(ecg,fs,pars);

%% Correlation Classification
classes=corrclass_cinc2017(ecg,QRS2,fs,pars.corrclass.scw1,pars.corrclass.ccmin1);
cc_res.perc_sc1_95=length(find(classes>1))/length(classes)*100;

classes2=corrclass_cinc2017(ecg,QRS2,fs,pars.corrclass.scw2,pars.corrclass.ccmin2);
cc_res.perc_sc1_98=length(find(classes2>1))/length(classes2)*100;



%% Rhythm Classification
[types,rhythm_res]=rhythmclass_cinc2017(ecg,QRS2,classes,amps,qrs_widths,fs,pars);

%% Get Averaged Beat
avbeats=avbeat_cinc2017(ecg,QRS2,classes,fs,pars);

%% Remove Averaged Beat
atrial_ecg=removeaverage_cinc2017(ecg,QRS2,classes,avbeats,fs,pars);

%% Detect AF
af_res=detectaf_cinc2017(ecg,QRS2,classes,types,atrial_ecg,avbeats,fs,pars);

%% Detect noise
noise_res=isnoise_cinc2017(ecg,QRS,QRS2,classes,...
	avbeats,types,amps,qrs_widths,atrial_ecg,fs,pars);

%% AF-Classficiation according to source template
if length(QRS)>=6
    RR=diff(QRS')/fs;
    [OriginCount,IrrEv,PACEv,AFEv] = comput_AFEv(RR);
    af_res.AFEv = AFEv;
    af_res.OriginCount = OriginCount;
    af_res.IrrEv = IrrEv;
    af_res.PACEv = PACEv;

else
	af_res.AFEv=NaN;
    af_res.OriginCount = NaN;
    af_res.IrrEv = NaN;
    af_res.PACEv = NaN;
end

%% Write results to a txt-file
varNames=getVarNames();
cell_data={...
	           recNr,...
                qrs_res.dd,...
                qrs_res.n_not_sel,...
                qrs_res.iqr_qrs,...
                qrs_res.qrs_range,...
                cc_res.perc_sc1_95,...
                cc_res.perc_sc1_98,...
                rhythm_res.hrtrt,...
                rhythm_res.Nscs,...
                rhythm_res.majorel,...
                rhythm_res.n_premajure,...
                rhythm_res.NPa,...
                rhythm_res.NPv,...
                rhythm_res.NPc,...
                rhythm_res.NPz,...
                rhythm_res.NPp,...
                rhythm_res.NPs,...
                rhythm_res.rcopa,...
                rhythm_res.perc_premajure,...
                rhythm_res.perc_regular,...
               rhythm_res.n_hist,...
               rhythm_res.n_hist2,...
               rhythm_res.hist_gap,...
               rhythm_res.n_amps,...
               rhythm_res.n_widths,...
                af_res.atrial_frequency,...
                af_res.P_amplitude,...
                af_res.P_amplitude2,...
                af_res.rr_irregularity,...
                af_res.rr_irregularity2,...
                af_res.AFEv,...
                  af_res.OriginCount,...
                    af_res.IrrEv,...
                      af_res.PACEv,...
                noise_res.mean_HR,...
                noise_res.max_pause,...
                noise_res.ratio_constant,...
                noise_res.ratio_ok,...
                noise_res.ratio_qrs_different,...
                noise_res.ratio_qrs_outof_amp,...
                noise_res.ratio_qrs_outof_width,...
                noise_res.ratio_samples_outof_amp,...
                noise_res.ratio_spikes,...
                noise_res.atrial_ratio,...
               noise_res.ratio_avbeat_constant_1,...
               noise_res.ratio_avbeat_constant_2,...
               noise_res.av12corr,...
               noise_res.n_classes_1_beat,...
               noise_res.sum_factor,...
               noise_res.n_over_th,...
               noise_res.ratio_avHighFreq_1,...
               noise_res.av_qrs_rest_ratio_1,...
               noise_res.ratio_avHighFreq_2,...
               noise_res.av_qrs_rest_ratio_2};
for i=1:6
	cell_data{end+1}=af_res.p_freq_rel(i);
end
for i=1:6
	cell_data{end+1}=noise_res.p_freq_rel(i);
end


%training mode: return dataset for record
if nargin<3
    result=cell2dataset(cell_data,'VarNames',varNames);
else
    %evaluation mode: return prediction for record based on given model
    ds=double(cell2dataset(cell_data,'VarNames',varNames));
    %TODO: fix this
    load('vars2use.mat')
    
    ds=ds(:,find(vars2use));
    %display(ds);
    result=predict(model,ds);
end



